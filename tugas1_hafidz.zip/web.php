<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('/home', function () {
    echo 10 + 10, "<br>";
    echo 15000 * 0.9, "<br>";
    date_default_timezone_set('Asia/Jakarta');
    echo date('d M Y h:i:s'), "\n";
});

Route::get('/BarangKeluar', function () {
    echo (
        "Palembang" . "<br>" .
        date('l, d/M/y') . "<p>" .
        "Laporan Barang Keluar" . "<p>"
    );

    echo "Baju";
    echo "<br>";
    $a = 250000 * 10;
    echo "250000 * 10 = ", $a;
    echo "<p>";

    echo "Jaket";
    echo "<br>";
    $b = 500000 * 50;
    echo "500000 * 50 = ", $b;
    echo "<p>";

    echo "Perlengkapan";
    echo "<br>";
    $c = 150000 * 100;
    echo "150000 * 100 = ", $c;
    echo "<p>";

    echo "Total";
    echo "<br>";
    echo "$a + $b+ $c = Rp", number_format($a + $b + $c, 2, ",", ".");
});
